package com.turvo.objectpool;

public class Calculator {
	
	private int a;
	
	public Calculator(int a) {
		this.a = a;
	}
	
	public void setA(int a) {
		this.a = a;
	}
	
	public int getA() {
		return this.a;
	}
	
}