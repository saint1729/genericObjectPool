package com.turvo.objectpool;

public class MainProgram {

	public static void main(String[] args) {
		
		CalculatorPool cp = new CalculatorPool(10, 20);
		
		cp.createObject();
		
	}
	
}
